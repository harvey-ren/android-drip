package com.xique.manage.construct.main.activity;


import com.alibaba.android.arouter.facade.annotation.Route;
import com.rqphp.publib.activity.BaseTitleActivity;
import com.rqphp.publib.util.ResourcesUtil;
import com.xique.manage.construct.R;
import com.xique.manage.construct.util.PageUtil;

import retrofit2.Retrofit;

/**
 * 知识库
 *
 * @author Harvey
 */
@Route(path = PageUtil.PATH_PAGE_REPOSITORY)
public class RepositoryActivity extends BaseTitleActivity {

    @Override
    protected void onInit() {
        setTitleText(ResourcesUtil.getString(this, R.string.repository));

    }

    @Override
    protected int setLayoutResId() {
        return R.layout.activity_repository;
    }
}
