package com.xique.manage.construct.entrance;

import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.text.TextUtils;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.alibaba.android.arouter.facade.annotation.Route;
import com.githang.statusbar.StatusBarCompat;
import com.rqphp.publib.activity.BaseTitleActivity;
import com.rqphp.publib.util.EditTextUtil;
import com.rqphp.publib.util.LogUtil;
import com.rqphp.publib.util.PageJumpUtil;
import com.rqphp.publib.util.ResourcesUtil;
import com.rqphp.publib.util.ScreenUtil;
import com.rqphp.publib.util.ToastUtil;
import com.rqphp.publib.view.IEditText;
import com.xique.manage.construct.R;
import com.xique.manage.construct.my.ChangePasswordActivity;
import com.xique.manage.construct.util.PageUtil;

/**
 * 登录界面
 *
 * @author Harvey
 */

@Route(path = PageUtil.PATH_PAGE_LOGIN)
public class LoginActivity extends BaseTitleActivity implements View.OnClickListener, IEditText.DrawableRightListener {

    private IEditText mEtPhone;
    private IEditText mEtPassword;
    private TextView mBtnLogin;
    private TextView mTvForgetPwd;

    private boolean isPassWordShow = false;

    //图标大小
    public static final int ICON_SIZE = ScreenUtil.dp2px(15);

    public void initViews() {
        mEtPhone = this.findViewById(R.id.et_phone);
        mEtPassword = this.findViewById(R.id.et_password);
        mBtnLogin = this.findViewById(R.id.btn_login);
        mTvForgetPwd = this.findViewById(R.id.tv_forget_pwd);
    }


    @Override
    protected int setLayoutResId() {
        return R.layout.activity_login;
    }


    @Override
    protected void setStatusBarColor() {
        StatusBarCompat.setTranslucent(getWindow(), true);
    }


    @Override
    protected void onInit() {
        initViews();
        setClickEvent();
        setUserNameIcon();
        setPwdIcon();
        setPwdState();
    }

    private void setClickEvent() {
        mTvForgetPwd.setOnClickListener(this);
        mBtnLogin.setOnClickListener(this);
        mEtPassword.setDrawableRightListener(this);
    }

    @Override
    public boolean isShowTitle() {
        return false;
    }


    private void setPwdIcon() {
        Drawable psdDrawable = ResourcesUtil.getDrawable(this, R.mipmap.ic_pwd); //获取图片
        psdDrawable.setBounds(0, 0, ICON_SIZE, ICON_SIZE);  //设置图片参数
        Drawable psdVisibleDrawable;
        if (isPassWordShow) {
            psdVisibleDrawable = ResourcesUtil.getDrawable(this, R.mipmap.ic_pwd_show); //获取图片
        } else {
            psdVisibleDrawable = ResourcesUtil.getDrawable(this, R.mipmap.ic_pwd_hide); //获取图片
        }
        psdVisibleDrawable.setBounds(0, 0, ICON_SIZE, ICON_SIZE);  //设置图片参数
        mEtPassword.setCompoundDrawables(psdDrawable, null, psdVisibleDrawable, null);  //设置控件位置
    }

    private void setUserNameIcon() {
        Drawable userDrawable = ResourcesUtil.getDrawable(this, R.mipmap.ic_user); //获取图片
        userDrawable.setBounds(0, 0, ICON_SIZE, ICON_SIZE);  //设置图片参数
        mEtPhone.setCompoundDrawables(userDrawable, null, null, null);  //设置控件位置
    }

    @Override
    public boolean isShowBackIcon() {
        return false;
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tv_forget_pwd:
                PageUtil.jumpForgetPasswordPage(this);
                break;
            case R.id.btn_login:
                checkLoginInfo();
                break;
        }
    }

    private void checkLoginInfo() {
//        String phoneNum = EditTextUtil.getTextString(mEtPhone);
//
//        if (TextUtils.isEmpty(phoneNum)) {
//            mEtPhone.setError("电话号码不能为空");
//            mEtPhone.requestFocus();
//            return;
//        }
//
//        if (phoneNum.length() < 11) {
//            mEtPhone.setError("电话号码不能少于11位");
//            mEtPhone.requestFocus();
//            return;
//        }
//
//        String password = EditTextUtil.getTextString(mEtPassword);
//
//        if (TextUtils.isEmpty(password)) {
//            mEtPassword.setError("密码不能为空");
//            mEtPassword.requestFocus();
//            return;
//        }
//
//        if (password.length() < 6) {
//            mEtPassword.setError("密码不能少于6位");
//            mEtPassword.requestFocus();
//            return;
//        }
        PageUtil.jumpToMainPage(this);
    }


    @Override
    public void onDrawableRightClick(View view) {
        isPassWordShow = !isPassWordShow;
        setPwdIcon();
        setPwdState();
    }

    private void setPwdState() {
        if (isPassWordShow) {
            EditTextUtil.showPassword(mEtPassword);
        } else {
            EditTextUtil.hidePassword(mEtPassword);
        }
    }
}
