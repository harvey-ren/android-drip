package com.xique.manage.construct.net;

import com.xique.manage.construct.TestModel;
import com.xique.manage.construct.Translation;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Query;

/**
 * @author Harvey
 * @description 获取到数据的接口
 * @date 2018/7/27 14:24
 * @copyright 成都喜鹊家居用品有限公司
 */
public interface GetRequestService {

    @Headers({"url_type:type2"})
    @GET("ajax.php?a=fy&f=auto&t=auto&w=我去")
    Call<Translation> getCall();

    @GET("/api/HouseTypeAssessment/GetInfoByCode")
    Call<TestModel> getData(@Query("fmt") String fmt, @Query("code") String code);

    @Multipart
    @POST("upload")
    Call<String> upload();
}
