package com.xique.manage.construct.notice.activity;

import com.alibaba.android.arouter.facade.annotation.Route;
import com.rqphp.publib.activity.BaseTitleActivity;
import com.xique.manage.construct.R;
import com.xique.manage.construct.util.PageUtil;

/**
 * @author Harvey
 * @description 通知详情界面
 * @date 2018/8/10 15:23
 * @copyright 成都喜鹊家居用品有限公司
 */
@Route(path = PageUtil.PATH_PAGE_NOTICE_DETAIL)
public class NoticeDetailActivity extends BaseTitleActivity {
    @Override
    protected int setLayoutResId() {
        return R.layout.layout_smartrefreshlayout_recyclerview;
    }

    @Override
    protected void onInit() {

    }
}
