package com.xique.manage.construct.my;

import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.alibaba.android.arouter.facade.annotation.Route;
import com.rqphp.publib.activity.BaseTitleActivity;
import com.rqphp.publib.util.JsonUtil;
import com.rqphp.publib.util.LogUtil;
import com.rqphp.publib.util.PageJumpUtil;
import com.rqphp.publib.util.ResourcesUtil;
import com.rqphp.publib.util.ToastUtil;
import com.xique.manage.construct.R;
import com.xique.manage.construct.util.PageUtil;

import org.json.JSONException;
import org.json.JSONObject;

import cn.smssdk.EventHandler;
import cn.smssdk.SMSSDK;


/**
 * @author Harvey
 * @description 忘记密码界面
 * @date 2018/8/2 11:57
 * @copyright 成都喜鹊家居用品有限公司
 */
@Route(path = PageUtil.PATH_PAGE_FORGET_PASSWORD)
public class ForgetPasswordActivity extends BaseTitleActivity implements View.OnClickListener {

    private EditText mEtPhoneNum;
    private TextView mTvGetVerificationCode;
    private EditText mEtVerificationCode;
    private TextView mBtnNextStep;
    private TextView mTvGetVoiceVerificationCode;
    private GetVerificationCodeCountDownTimer mTimer;
    private static final long GET_VERIFICATION_CODE_TIME = 40 * 1000;
    private CharSequence tempPhoneNum;
    private CharSequence tempVerificationCode;
    private Handler mHandler;

    public void initViews() {
        mEtPhoneNum = (EditText) this.findViewById(R.id.et_phone_num);
        mTvGetVerificationCode = (TextView) this.findViewById(R.id.tv_get_verification_code);
        mEtVerificationCode = (EditText) this.findViewById(R.id.et_verification_code);
        mBtnNextStep = (TextView) this.findViewById(R.id.btn_next_step);
        mTvGetVoiceVerificationCode = (TextView) this.findViewById(R.id.tv_get_voice_verification_code);
    }


    @Override
    protected int setLayoutResId() {
        return R.layout.activity_forget_password;
    }

    @Override
    protected void onInit() {
        setTitleText(ResourcesUtil.getString(this, R.string.forget_password));
        initViews();
        addEtPhoneNumListener();
        addEtVerificationCodeListener();
        mTvGetVerificationCode.setOnClickListener(this);
        mBtnNextStep.setOnClickListener(this);
        mTvGetVoiceVerificationCode.setOnClickListener(this);
        mHandler = new MyHandler();
        SMSSDK.registerEventHandler(eh);
    }

    //注册回调监听，放到发送和验证前注册，注意这里是子线程需要传到主线程中去操作后续提示
    EventHandler eh = new EventHandler() {
        @Override
        public void afterEvent(int event, int result, Object data) {
            Message msg = new Message();
            msg.arg1 = event;
            msg.arg2 = result;
            msg.obj = data;
            mHandler.sendMessage(msg);
        }
    };

    @Override
    protected void onResume() {
        super.onResume();
    }

    private class MyHandler extends Handler {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);

            LogUtil.error("" + msg.obj);
            int result = msg.arg2;
            int event = msg.arg1;
            Object data = msg.obj;
            if (result == SMSSDK.RESULT_COMPLETE) {
                //回调完成
                if (event == SMSSDK.EVENT_SUBMIT_VERIFICATION_CODE) {
                    //提交验证码成功
                    PageUtil.jumpToChangePassword(ForgetPasswordActivity.this);
                } else if (event == SMSSDK.EVENT_GET_VERIFICATION_CODE) {
                    //获取验证码成功
                    ToastUtil.shortShow(ForgetPasswordActivity.this, ResourcesUtil.getString(ForgetPasswordActivity.this, R.string.get_verification_code_success));
                } else if (event == SMSSDK.EVENT_GET_SUPPORTED_COUNTRIES) {
                    //返回支持发送验证码的国家列表
                }
            } else {
                ((Throwable) data).getMessage();
                try {
                    if (data != null) {
                        JSONObject jsonObject = new JSONObject(((Throwable) data).getMessage());
                        if (jsonObject.has("status")) {
                            int status = jsonObject.getInt("status");
                            showGetVerificationCodeStatusInfo(status);
                        } else {
                            ToastUtil.shortShow(ForgetPasswordActivity.this, ResourcesUtil.getString(ForgetPasswordActivity.this, R.string.get_verification_code_fail));
                        }
                    } else {
                        ToastUtil.shortShow(ForgetPasswordActivity.this, ResourcesUtil.getString(ForgetPasswordActivity.this, R.string.get_verification_code_fail));
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void showGetVerificationCodeStatusInfo(int status) {
        String info;
        switch (status) {
            /**
             * 456	手机号码为空	提交的手机号码或者区号为空。
             * 457	手机号码格式错误	提交的手机号格式不正确（包括手机的区号）。
             * 458	手机号码在黑名单中	手机号码在发送黑名单中。
             * 459	无appKey的控制数据	获取appKey控制发送短信的数据失败。
             * 460	无权限发送短信	没有打开客户端发送短信的开关。
             * 461	不支持该地区发送短信	没有开通给当前地区发送短信的功能。
             * 462	每分钟发送次数超限	每分钟发送短信的数量超过限制。
             * 463	手机号码每天发送次数超限	手机号码在当前APP内每天发送短信的次数超出限制。
             * 464	每台手机每天发送次数超限	每台手机每天发送短信的次数超限。
             * 465	号码在App中每天发送短信的次数超限	手机号码在APP中每天发送短信的数量超限。
             * 466	校验的验证码为空	提交的校验验证码为空。
             * 467	校验验证码请求频繁	5分钟内校验错误超过3次，验证码失效。
             * 468	需要校验的验证码错误	用户提交校验的验证码错误。
             */
            case 456:
                info = "手机号码为空";
                break;
            case 457:
                info = "手机号码格式错误";
                break;
            case 458:
                info = "手机号码在黑名单中";
                break;
            case 460:
                info = "无权限发送短信";
                break;
            case 462:
                info = "每分钟发送次数超限";
                break;
            case 463:
                info = "手机号码每天发送次数超限";
                break;
            case 464:
                info = "每台手机每天发送次数超限";
                break;
            case 465:
                info = "号码在App中每天发送短信的次数超限";
                break;
            case 466:
                info = "验证码为空";
                break;
            case 467:
                info = "验证码请求频繁";
                break;
            case 468:
                info = "验证码错误";
                break;
            default:
                info = "状态未知，请联系客服";
                break;
        }
        ToastUtil.shortShow(this, info);
    }

    private void addEtVerificationCodeListener() {
        mEtVerificationCode.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                tempVerificationCode = charSequence;
            }

            @Override
            public void afterTextChanged(Editable editable) {
                if (tempVerificationCode != null && tempVerificationCode.toString().length() == 6 && tempPhoneNum != null && tempPhoneNum.toString().length() == 11) {
                    mBtnNextStep.setEnabled(true);
                } else {
                    mBtnNextStep.setEnabled(false);
                }
            }
        });
    }


    private void addEtPhoneNumListener() {
        mEtPhoneNum.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                tempPhoneNum = charSequence;
            }

            @Override
            public void afterTextChanged(Editable editable) {
                mEtVerificationCode.setText("");
                if (tempPhoneNum != null && tempPhoneNum.length() == 11) {
                    mTvGetVerificationCode.setEnabled(true);
                } else {
                    mTvGetVerificationCode.setEnabled(false);
                }
            }
        });
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_next_step:
                // 提交验证码，其中的code表示验证码，如“1357”
                SMSSDK.submitVerificationCode("86", mEtPhoneNum.getText().toString(), mEtVerificationCode.getText().toString());
                break;

            case R.id.tv_get_verification_code:
                String phoneNume = mEtPhoneNum.getText().toString();
                if (!TextUtils.isEmpty(phoneNume)) {
                    if (mTimer == null) {
                        mTimer = new GetVerificationCodeCountDownTimer(GET_VERIFICATION_CODE_TIME, 1000);
                    }
                    mTimer.start();
                    // 请求验证码，其中country表示国家代码，如“86”；phone表示手机号码，如“13800138000”
                    SMSSDK.getVerificationCode("86", phoneNume);
                } else {
                    ToastUtil.shortShow(this, "请输入手机号码");
                }
                break;

            case R.id.tv_get_voice_verification_code:
                //接入mob语音验证码功能
                SMSSDK.getVoiceVerifyCode("86", mEtPhoneNum.getText().toString());
                break;
        }
    }

    /**
     * 倒计时实现
     */
    class GetVerificationCodeCountDownTimer extends CountDownTimer {

        public GetVerificationCodeCountDownTimer(long millisInFuture, long countDownInterval) {
            super(millisInFuture, countDownInterval);
        }

        @Override
        public void onTick(long millisUntilFinished) {
            mTvGetVerificationCode.setEnabled(false);
            mTvGetVerificationCode.setText(String.format(ResourcesUtil.getString(ForgetPasswordActivity.this, R.string.is_can_get_verification_code), (millisUntilFinished / 1000)));
        }

        @Override
        public void onFinish() {
            if (mEtPhoneNum.getEditableText().toString().length() == 6)
                mTvGetVerificationCode.setEnabled(true);
            mTvGetVerificationCode.setText(ResourcesUtil.getString(ForgetPasswordActivity.this, R.string.get_verification_code));
        }
    }

    protected void onStop() {
        super.onStop();

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mTimer != null) {
            mTimer.cancel();
            mTimer = null;
        }
        if (eh != null) {
            //用完回调要注销掉，否则可能会出现内存泄露
            SMSSDK.unregisterEventHandler(eh);
        }


    }
}
