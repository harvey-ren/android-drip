package com.xique.manage.construct.my;

import android.graphics.drawable.Drawable;
import android.os.CountDownTimer;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.alibaba.android.arouter.facade.annotation.Route;
import com.rqphp.publib.activity.BaseTitleActivity;
import com.rqphp.publib.util.EditTextUtil;
import com.rqphp.publib.util.ResourcesUtil;
import com.rqphp.publib.util.ScreenUtil;
import com.rqphp.publib.view.IEditText;
import com.xique.manage.construct.R;
import com.xique.manage.construct.util.PageUtil;

import retrofit2.Retrofit;

import static com.xique.manage.construct.entrance.LoginActivity.ICON_SIZE;

/**
 * 修改密码界面
 *
 * @author Harvey
 * @date 2018/7/24 10:46
 */
@Route(path = PageUtil.PATH_PAGE_CHANGE_PASSWORD)
public class ChangePasswordActivity extends BaseTitleActivity implements View.OnClickListener {

    private IEditText mEtNewPwd;
    private IEditText mEtNewPwdAgain;
    private TextView mBtnConfirmMod;
    private boolean isPassWordShow = false;
    private boolean isPassWordAgainShow = false;


    @Override
    protected int setLayoutResId() {
        return R.layout.activity_change_password;
    }

    public void initViews() {
        mEtNewPwd = this.findViewById(R.id.et_new_pwd);
        mEtNewPwdAgain = this.findViewById(R.id.et_new_pwd_again);
        mBtnConfirmMod = this.findViewById(R.id.btn_confirm_mod);
    }

    @Override
    protected void onInit() {
        setTitleText(ResourcesUtil.getString(this, R.string.change_password));
        initViews();
        setNewPwdIcon(isPassWordShow, mEtNewPwd);
        setNewPwdIcon(isPassWordAgainShow, mEtNewPwdAgain);
        setPwdState(isPassWordShow, mEtNewPwd);
        setPwdState(isPassWordAgainShow, mEtNewPwdAgain);
        mBtnConfirmMod.setOnClickListener(this);
        mEtNewPwd.setDrawableRightListener(new IEditText.DrawableRightListener() {
            @Override
            public void onDrawableRightClick(View view) {
                isPassWordShow = !isPassWordShow;
                setNewPwdIcon(isPassWordShow, mEtNewPwd);
                setPwdState(isPassWordShow, mEtNewPwd);
            }
        });
        mEtNewPwdAgain.setDrawableRightListener(new IEditText.DrawableRightListener() {
            @Override
            public void onDrawableRightClick(View view) {
                isPassWordAgainShow = !isPassWordAgainShow;
                setNewPwdIcon(isPassWordAgainShow, mEtNewPwdAgain);
                setPwdState(isPassWordAgainShow, mEtNewPwdAgain);
            }
        });
        addNewPwdListener();
        addNewPwdAgainListener();
    }

    private CharSequence tempNewPwdAgain;
    private CharSequence tempNewPwd;


    private void addNewPwdAgainListener() {
        mEtNewPwdAgain.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                tempNewPwdAgain = charSequence;
            }

            @Override
            public void afterTextChanged(Editable editable) {
                if (tempNewPwd != null && tempNewPwdAgain != null && tempNewPwd.length() > 0
                        && tempNewPwd.toString().equals(tempNewPwdAgain.toString())) {
                    mBtnConfirmMod.setEnabled(true);
                } else {
                    mBtnConfirmMod.setEnabled(false);
                }
            }
        });
    }

    private void addNewPwdListener() {
        mEtNewPwd.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                tempNewPwd = charSequence;
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });
    }

    private void setPwdState(boolean isPassWordShow, EditText editText) {
        if (isPassWordShow) {
            EditTextUtil.showPassword(editText);
        } else {
            EditTextUtil.hidePassword(editText);
        }
    }

    private void setNewPwdIcon(boolean isPassWordShow, EditText editText) {
        Drawable psdDrawable = ResourcesUtil.getDrawable(this, R.mipmap.ic_new_pwd); //获取图片
        psdDrawable.setBounds(0, 0, ICON_SIZE, ICON_SIZE);  //设置图片参数
        Drawable psdVisibleDrawable;
        if (isPassWordShow) {
            psdVisibleDrawable = ResourcesUtil.getDrawable(this, R.mipmap.ic_pwd_show); //获取图片
        } else {
            psdVisibleDrawable = ResourcesUtil.getDrawable(this, R.mipmap.ic_pwd_hide); //获取图片
        }
        psdVisibleDrawable.setBounds(0, 0, ICON_SIZE, ICON_SIZE);  //设置图片参数
        editText.setCompoundDrawables(psdDrawable, null, psdVisibleDrawable, null);  //设置控件位置
    }


    @Override
    public void onClick(View view) {
        PageUtil.jumpToLoginPage(this);
    }
}
