package com.xique.manage.construct;

import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.rqphp.publib.activity.BaseTitleActivity;
import com.rqphp.publib.util.ToastUtil;
import com.rqphp.publib.view.NetWorkImageView;
import com.xique.manage.construct.net.RetrofitCallback;
import com.xique.manage.construct.net.ApiManager;

/**
 * @author Harvey
 * @date 2018/7/27 13:42
 */
public class NetTestAcitity extends BaseTitleActivity implements View.OnClickListener {


    private Button mBtnTest;
    private TextView mTvMsg;

    private Button mBtnTest1;
    private NetWorkImageView mImgView;
    private String url = "http://c.hiphotos.baidu.com/image/pic/item/d439b6003af33a87433692cfca5c10385243b588.jpg";
//    private String url = "http://img5.duitang.com/uploads/item/201411/29/20141129013744_UJEuu.gif";


    @Override
    protected int setLayoutResId() {
        return R.layout.acticity_net_test;
    }

    @Override
    protected void onInit() {
        initViews();
        mBtnTest.setOnClickListener(this);
        mBtnTest1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ApiManager.getData(NetTestAcitity.this, new RetrofitCallback() {
                    @Override
                    public void onSuccess(Object ret) {

                    }

                    @Override
                    public void onError(int errCode, String errMsg) {

                    }

                    @Override
                    public void onFailure() {

                    }
                });
            }
        });
    }

    public void initViews() {
        mBtnTest = (Button) this.findViewById(R.id.btn_test);
        mTvMsg = (TextView) this.findViewById(R.id.tv_msg);
        mBtnTest1 = (Button) this.findViewById(R.id.btn_test1);
        mImgView = (NetWorkImageView) this.findViewById(R.id.imgView);

    }

    @Override
    public void onClick(View view) {
        request();
        mImgView.setImgUrl(url);
    }

    private void request() {
        ApiManager.login(this, "json", "16406B914BD", new RetrofitCallback() {
            @Override
            public void onSuccess(Object ret) {
                ToastUtil.shortShow(NetTestAcitity.this, "请求成功");
            }

            @Override
            public void onError(int err_code, String err_msg) {

            }

            @Override
            public void onFailure() {

            }
        });
    }
}
