package com.xique.manage.construct.config;

import android.content.Context;

import com.rqphp.publib.config.IFrameworkConfig;
import com.rqphp.publib.config.IFrameworkResConfig;

/**
 * @author Harvey
 * @description
 * @date 2018/8/1 17:12
 * @copyright 成都喜鹊家居用品有限公司
 */
public class IFrameworkCofigImpl implements IFrameworkConfig {

    private Context context;

    IFrameworkResConfig frameworkResConfig;

    public IFrameworkCofigImpl(Context context) {
        this.context = context;
        frameworkResConfig = new IFrameworkResConfigImpl();
    }

    @Override
    public IFrameworkResConfig getFrameworkResConfig() {
        return frameworkResConfig;
    }
}
