package com.xique.manage.construct;

import com.baidu.mapapi.map.MapView;
import com.rqphp.publib.activity.BaseTitleActivity;
import com.xique.manage.construct.R;

/**
 * @author Harvey
 * @date 2018/7/26 15:32
 */
public class MapActivity extends BaseTitleActivity {

    private MapView mMapView;

    @Override
    protected int setLayoutResId() {
        return R.layout.activity_map;
    }

    @Override
    protected void onInit() {
        initViews();
    }


    public void initViews() {
        mMapView = findViewById(R.id.mapView);
        mMapView.getMap();
    }


}
