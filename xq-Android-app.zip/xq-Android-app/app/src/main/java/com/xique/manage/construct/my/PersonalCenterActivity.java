package com.xique.manage.construct.my;



import com.alibaba.android.arouter.facade.annotation.Route;
import com.rqphp.publib.activity.BaseTitleActivity;
import com.rqphp.publib.util.ResourcesUtil;
import com.xique.manage.construct.R;
import com.xique.manage.construct.util.PageUtil;

/**
 * 个人中心
 *
 * @author Harvey
 */
@Route(path = PageUtil.PATH_PAGE_PERSONAL_CENTER)
public class PersonalCenterActivity extends BaseTitleActivity {


    @Override
    protected void onInit() {
        setTitleText(ResourcesUtil.getString(this, R.string.personal_center));
    }

    @Override
    protected int setLayoutResId() {
        return R.layout.activity_personal_center;
    }
}
