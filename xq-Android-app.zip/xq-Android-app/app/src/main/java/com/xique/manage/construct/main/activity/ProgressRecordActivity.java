package com.xique.manage.construct.main.activity;

import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.alibaba.android.arouter.facade.annotation.Route;
import com.rqphp.publib.activity.BaseTitleActivity;
import com.rqphp.publib.util.PageJumpUtil;
import com.rqphp.publib.util.ResourcesUtil;
import com.xique.manage.construct.R;
import com.xique.manage.construct.util.PageUtil;

/**
 * @author Harvey
 * @description
 * @date 2018/8/9 10:33
 * @copyright 成都喜鹊家居用品有限公司
 */

@Route(path = PageUtil.PATH_PAGE_PROGRESS_RECORD)
public class ProgressRecordActivity extends BaseTitleActivity implements View.OnClickListener {

    private TextView mTvCurProcess;
    private TextView mTvPlanEnter;
    private TextView mTvPlanExit;
    private TextView mTvRealEnter;
    private TextView mTvRealExit;
    private TextView mTvProcessDelay;
    private TextView mTvTotalDelay;
    private TextView mTvDelayReason;
    private EditText mEtDelayReason;
    private EditText mEtCompletion;
    private TextView mBtnConfirmRecord;

    public void initViews() {
        mTvCurProcess = this.findViewById(R.id.tv_cur_process);
        mTvPlanEnter = this.findViewById(R.id.tv_plan_enter);
        mTvPlanExit = this.findViewById(R.id.tv_plan_exit);
        mTvRealEnter = this.findViewById(R.id.tv_real_enter);
        mTvRealExit = this.findViewById(R.id.tv_real_exit);
        mTvProcessDelay = this.findViewById(R.id.tv_process_delay);
        mTvTotalDelay = this.findViewById(R.id.tv_total_delay);
        mTvDelayReason = this.findViewById(R.id.tv_delay_reason);
        mEtDelayReason = this.findViewById(R.id.et_delay_reason);
        mEtCompletion = this.findViewById(R.id.et_completion);
        mBtnConfirmRecord = this.findViewById(R.id.btn_confirm_record);
    }


    @Override
    protected int setLayoutResId() {
        return R.layout.activity_progress_record;
    }

    @Override
    protected void onInit() {
        setTitleText(ResourcesUtil.getString(this, R.string.progress_record));
        initViews();
        mTvRealEnter.setOnClickListener(this);
        mTvRealExit.setOnClickListener(this);
        mTvDelayReason.setOnClickListener(this);
        mBtnConfirmRecord.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()) {
            case R.id.tv_delay_reason:
                PageUtil.jumpToDelayReason(this);
                break;

            case R.id.btn_confirm_record:
                this.finish();
                break;

            case R.id.tv_real_enter:

                break;

            case R.id.tv_real_exit:

                break;
        }
    }
}
