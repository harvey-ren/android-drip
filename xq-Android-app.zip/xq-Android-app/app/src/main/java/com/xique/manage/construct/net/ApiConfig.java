package com.xique.manage.construct.net;

/**
 * @author Harvey
 * @description
 * @date 2018/7/30 17:26
 * @copyright 成都喜鹊家居用品有限公司
 */
public class ApiConfig {

    public static final String BASE_URL = "http://vip.xique.com/";

    public static final String BASE_URL_1 = "http://fy.iciba.com/";
}
