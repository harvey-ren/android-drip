package com.xique.manage.construct.main.activity;

import com.alibaba.android.arouter.facade.annotation.Route;
import com.rqphp.publib.activity.BaseTitleActivity;
import com.rqphp.publib.util.ResourcesUtil;
import com.xique.manage.construct.R;
import com.xique.manage.construct.util.PageUtil;

/**
 * @author Harvey
 * @description 延时原因
 * @date 2018/8/10 18:58
 * @copyright 成都喜鹊家居用品有限公司
 */
@Route(path = PageUtil.PATH_PAGE_DELAY_REASON)
public class DelayReasonActivity extends BaseTitleActivity {
    @Override
    protected int setLayoutResId() {
        return R.layout.layout_smartrefreshlayout_recyclerview;
    }

    @Override
    protected void onInit() {
        setTitleText(ResourcesUtil.getString(this, R.string.delay_reason));
    }
}
