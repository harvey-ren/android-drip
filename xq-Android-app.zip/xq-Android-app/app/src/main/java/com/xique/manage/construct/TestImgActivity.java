package com.xique.manage.construct;

import com.rqphp.publib.activity.BaseTitleActivity;
import com.rqphp.publib.view.NetWorkImageView;

/**
 * @author Harvey
 * @description
 * @date 2018/7/31 11:43
 * @copyright 成都喜鹊家居用品有限公司
 */
public class TestImgActivity extends BaseTitleActivity {

    private String url = "http://img5.duitang.com/uploads/item/201411/29/20141129013744_UJEuu.gif";

    private NetWorkImageView mImgView;

    @Override
    protected int setLayoutResId() {
        return R.layout.activity_img_test;
    }

    @Override
    protected void onInit() {
        initViews();
    }


    public void initViews() {
        mImgView = this.findViewById(R.id.imgView);
        mImgView.setImgUrl(url);
    }


}
