package com.xique.manage.construct;

/**
 * @author Harvey
 * @description
 * @date 2018/7/27 16:42
 * @copyright 成都喜鹊家居用品有限公司
 */
public class TestModel {


    /**
     * State : 1
     * Message : 提交成功
     * Data : {"ID":2,"GeJu":"五居及以上","MianJi":"170-220㎡","WoShiChuangWaiJingGuan":"公园","YangTaiChuangWaiJingGuan":"学校","Name":"龙","CommunityName":"大力哥","CreateTime":1529121150141}
     */

    private int State;
    private String Message;
    private DataBean Data;

    public int getState() {
        return State;
    }

    public void setState(int State) {
        this.State = State;
    }

    public String getMessage() {
        return Message;
    }

    public void setMessage(String Message) {
        this.Message = Message;
    }

    public DataBean getData() {
        return Data;
    }

    public void setData(DataBean Data) {
        this.Data = Data;
    }

    public static class DataBean {
        /**
         * ID : 2
         * GeJu : 五居及以上
         * MianJi : 170-220㎡
         * WoShiChuangWaiJingGuan : 公园
         * YangTaiChuangWaiJingGuan : 学校
         * Name : 龙
         * CommunityName : 大力哥
         * CreateTime : 1529121150141
         */

        private int ID;
        private String GeJu;
        private String MianJi;
        private String WoShiChuangWaiJingGuan;
        private String YangTaiChuangWaiJingGuan;
        private String Name;
        private String CommunityName;
        private long CreateTime;

        public int getID() {
            return ID;
        }

        public void setID(int ID) {
            this.ID = ID;
        }

        public String getGeJu() {
            return GeJu;
        }

        public void setGeJu(String GeJu) {
            this.GeJu = GeJu;
        }

        public String getMianJi() {
            return MianJi;
        }

        public void setMianJi(String MianJi) {
            this.MianJi = MianJi;
        }

        public String getWoShiChuangWaiJingGuan() {
            return WoShiChuangWaiJingGuan;
        }

        public void setWoShiChuangWaiJingGuan(String WoShiChuangWaiJingGuan) {
            this.WoShiChuangWaiJingGuan = WoShiChuangWaiJingGuan;
        }

        public String getYangTaiChuangWaiJingGuan() {
            return YangTaiChuangWaiJingGuan;
        }

        public void setYangTaiChuangWaiJingGuan(String YangTaiChuangWaiJingGuan) {
            this.YangTaiChuangWaiJingGuan = YangTaiChuangWaiJingGuan;
        }

        public String getName() {
            return Name;
        }

        public void setName(String Name) {
            this.Name = Name;
        }

        public String getCommunityName() {
            return CommunityName;
        }

        public void setCommunityName(String CommunityName) {
            this.CommunityName = CommunityName;
        }

        public long getCreateTime() {
            return CreateTime;
        }

        public void setCreateTime(long CreateTime) {
            this.CreateTime = CreateTime;
        }
    }
}
