package com.xique.manage.construct.net;

import android.content.Context;

import com.xique.manage.construct.TestModel;
import com.xique.manage.construct.Translation;

import retrofit2.Call;

/**
 * 所有接口管理类
 *
 * @author Harvey
 * @description
 * @date 2018/7/27 17:04
 * @copyright 成都喜鹊家居用品有限公司
 */
public class ApiManager {

    public static void login(Context context, String fmt, String code, RetrofitCallback callback) {
        ApiClient apiClient = ApiClient.getInstance();
        GetRequestService requestService = apiClient.getRequestService(GetRequestService.class);
        Call<TestModel> call = requestService.getData(fmt, code);
        apiClient.request(context, call, callback);
    }


    public static void getData(Context context, RetrofitCallback apiCallback) {
        ApiClient apiClient = ApiClient.getInstance();
        GetRequestService requestService = apiClient.getRequestService(GetRequestService.class);
        Call<Translation> call = requestService.getCall();
        apiClient.request(context, "请求中...", call, apiCallback);
    }
}
