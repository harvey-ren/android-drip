package com.xique.manage.construct;

/**
 * @author Harvey
 * @date 2018/7/27 14:00
 */
public class Translation {

    private String status;
    private content content;

    private static class content {
        private String from;
        private String to;
        private String vendor;
        private String out;
        private int errNo;
    }
}
