package com.xique.manage.construct.entrance;

import android.os.Handler;

import com.githang.statusbar.StatusBarCompat;
import com.rqphp.publib.activity.BaseTitleActivity;
import com.xique.manage.construct.R;
import com.xique.manage.construct.util.PageUtil;


/**
 * 闪屏界面
 *
 * @author Harvey
 */

public class SplashActivity extends BaseTitleActivity {

    private Handler handler;
    private SplashRunnable splashRunnable;

    @Override
    protected int setLayoutResId() {
        return R.layout.activity_splash;
    }


    @Override
    protected void onInit() {
        handler = new Handler();
        splashRunnable = new SplashRunnable();
        handler.postDelayed(splashRunnable, 3000);
    }

    @Override
    protected void setStatusBarColor() {
        StatusBarCompat.setTranslucent(getWindow(), true);
    }

    class SplashRunnable implements Runnable {
        public void run() {
            PageUtil.jumpToLoginPage(SplashActivity.this);
//            SplashActivity.this.finish();
        }
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (handler != null) {
            handler.removeCallbacks(splashRunnable);
            handler = null;
        }
    }

    @Override
    public boolean isShowTitle() {
        return false;
    }
}


