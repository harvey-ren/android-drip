package com.xique.manage.construct.config;

import android.graphics.Typeface;

import com.rqphp.publib.config.IFrameworkResConfig;
import com.xique.manage.construct.R;

/**
 * @author Harvey
 * @description 程序的资源配置
 * @date 2018/8/1 17:14
 * @copyright 成都喜鹊家居用品有限公司
 */
public class IFrameworkResConfigImpl implements IFrameworkResConfig {

    @Override
    public Typeface getNormalTypeface() {
        return null;
    }

    @Override
    public Typeface getBoldTypeface() {
        return null;
    }

    @Override
    public String getAlbumDirName() {
        return null;
    }

    @Override
    public String getTempDirName() {
        return null;
    }

    @Override
    public int getDefaultAvatarRes() {
        return 0;
    }

    @Override
    public int getErrorAvatarRes() {
        return 0;
    }

    @Override
    public int getPrimaryColor() {
        return R.color.colorPrimary;
    }

    @Override
    public String getAppInnerName() {
        return null;
    }

    @Override
    public int getTitleTextColor() {
        return R.color.color_10;
    }


    @Override
    public int getTitleBgColor() {
        return R.color.color_white;
    }

    @Override
    public int getBackIcon() {
        return R.mipmap.ic_back;
    }
}
