package com.xique.manage.construct.my;



import com.alibaba.android.arouter.facade.annotation.Route;
import com.rqphp.publib.activity.BaseTitleActivity;
import com.rqphp.publib.util.ResourcesUtil;
import com.xique.manage.construct.R;
import com.xique.manage.construct.util.PageUtil;

/**
 * 意见反馈
 * @author Harvey
 */
@Route(path = PageUtil.PATH_PAGE_FEEDBACK)
public class FeedbackActivity extends BaseTitleActivity {

    @Override
    protected void onInit() {
        setTitleText(ResourcesUtil.getString(this, R.string.feedback));
    }

    @Override
    protected int setLayoutResId() {
        return R.layout.activity_feedback;
    }
}
