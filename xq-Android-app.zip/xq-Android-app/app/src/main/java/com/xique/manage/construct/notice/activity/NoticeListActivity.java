package com.xique.manage.construct.notice.activity;

import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.alibaba.android.arouter.facade.annotation.Route;
import com.rqphp.publib.activity.BaseTitleActivity;
import com.rqphp.publib.util.ResourcesUtil;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.xique.manage.construct.R;
import com.xique.manage.construct.notice.adapter.NoticeListAdapter;
import com.xique.manage.construct.util.PageUtil;
import com.xique.manage.construct.util.RecyclerViewUtil;

/**
 * @author Harvey
 * @description 通知列表页面
 * @date 2018/8/9 16:55
 * @copyright 成都喜鹊家居用品有限公司
 */
@Route(path = PageUtil.PATH_PAGE_NOTICE_LIST)
public class NoticeListActivity extends BaseTitleActivity {
    private SmartRefreshLayout mRefreshLayout;
    private RecyclerView mRecyclerView;

    @Override
    protected int setLayoutResId() {
        return R.layout.layout_smartrefreshlayout_recyclerview;
    }

    @Override
    protected void onInit() {
        setTitleText(ResourcesUtil.getString(this, R.string.notice_list));
        mRefreshLayout = findViewById(R.id.refreshLayout);
        mRecyclerView = findViewById(R.id.recyclerView);
        RecyclerViewUtil.getRecyclerView(this, mRefreshLayout, mRecyclerView, new LinearLayoutManager(this), new DefaultItemAnimator(), true);

        mRecyclerView.setAdapter(new NoticeListAdapter(this));
    }
}
