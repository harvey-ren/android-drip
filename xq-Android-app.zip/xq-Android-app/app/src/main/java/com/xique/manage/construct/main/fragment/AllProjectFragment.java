package com.xique.manage.construct.main.fragment;

import android.view.View;

import com.rqphp.publib.base.BaseLazyFragment;
import com.xique.manage.construct.R;

/**
 * @author Harvey
 * @description 所有项目
 * @date 2018/8/6 16:19
 * @copyright 成都喜鹊家居用品有限公司
 */
public class AllProjectFragment extends BaseLazyFragment {

    /**
     * 懒加载
     */
    @Override
    public void onLazyLoad() {

    }

    //设置系统文件
    @Override
    protected int setLayoutResId() {
        return R.layout.fragment_all_project;
    }

    @Override
    protected void onInit(View view) {

    }
}
