package com.xique.manage.construct.main.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.rqphp.publib.adapter.HeaderFooterRecyclerViewAdapter;
import com.rqphp.publib.base.BaseViewHolder;
import com.rqphp.publib.util.PageJumpUtil;
import com.xique.manage.construct.R;
import com.xique.manage.construct.main.activity.AddMaterialsActivity;
import com.xique.manage.construct.main.activity.CheckoutMaterialsActivity;
import com.xique.manage.construct.main.activity.CurProjectInfoActivity;
import com.xique.manage.construct.main.activity.ExceptionSubmitActivity;
import com.xique.manage.construct.main.activity.RecycleMaterialsActivity;
import com.xique.manage.construct.main.activity.TempWorkerActivity;
import com.xique.manage.construct.main.activity.WorkHoursRecordActivity;
import com.xique.manage.construct.util.PageUtil;

/**
 * @author Harvey
 * @description 当前项目RecyclerView的适配器
 * @date 2018/8/8 16:40
 * @copyright 成都喜鹊家居用品有限公司
 */
public class CurProjectRecyclerViewAdapter extends RecyclerView.Adapter<BaseViewHolder> {

    private Context mContext;

    public CurProjectRecyclerViewAdapter(Context context) {
        mContext = context;
    }

    @NonNull
    @Override
    public BaseViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.item_record_cur_project_recyclerview, viewGroup, false);
        return new CurProjectViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull BaseViewHolder baseViewHolder, int position) {
        baseViewHolder.renderView(position);
    }

    @Override
    public int getItemCount() {
        return 1;
    }


    private class CurProjectViewHolder extends BaseViewHolder implements View.OnClickListener {

        LinearLayout mLayoutAssign;
        LinearLayout mLayoutTemp;
        LinearLayout mLayoutAddMaterial;
        LinearLayout mLayoutRecycleMaterial;
        LinearLayout mLayoutCheckoutMaterial;
        LinearLayout mLayoutException;
        LinearLayout mLayoutHourRecord;
        TextView mBtnProgressRecord;
        LinearLayout mLayoutProjectProcess;

        public CurProjectViewHolder(View convertView) {
            super(convertView);
            mLayoutAssign = convertView.findViewById(R.id.layout_assign);
            mLayoutTemp = convertView.findViewById(R.id.layout_temp);
            mLayoutAddMaterial = convertView.findViewById(R.id.layout_add_material);
            mLayoutRecycleMaterial = convertView.findViewById(R.id.layout_recycle_material);
            mLayoutCheckoutMaterial = convertView.findViewById(R.id.layout_checkout_material);
            mLayoutException = convertView.findViewById(R.id.layout_exception);
            mLayoutHourRecord = convertView.findViewById(R.id.layout_hour_record);
            mBtnProgressRecord = convertView.findViewById(R.id.btn_progress_record);
            mLayoutProjectProcess = convertView.findViewById(R.id.layout_project_process);

            mLayoutAssign.setOnClickListener(this);
            mLayoutTemp.setOnClickListener(this);
            mLayoutAddMaterial.setOnClickListener(this);
            mLayoutRecycleMaterial.setOnClickListener(this);
            mLayoutCheckoutMaterial.setOnClickListener(this);
            mLayoutException.setOnClickListener(this);
            mLayoutHourRecord.setOnClickListener(this);
            mBtnProgressRecord.setOnClickListener(this);
            mLayoutProjectProcess.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            switch (view.getId()) {

                case R.id.layout_project_process:
                    PageUtil.jumpToCurProject(mContext);
                    break;

                case R.id.layout_assign:
                    PageUtil.jumpToAssignPage(mContext);
                    break;

                case R.id.layout_temp:
                    PageUtil.jumpToTempWorker(mContext);
                    break;

                case R.id.layout_add_material:
                    PageUtil.jumpToAddMaterial(mContext);
                    break;

                case R.id.layout_recycle_material:
                    PageUtil.jumpToRecycleMaterial(mContext);
                    break;

                case R.id.layout_checkout_material:
                    PageUtil.jumpToCheckoutMaterial(mContext);
                    break;

                case R.id.layout_exception:
                    PageUtil.jumpToExceptionSubmit(mContext);
                    break;

                case R.id.layout_hour_record:
                    PageUtil.jumpToWorkHoursRecord(mContext);
                    break;

                case R.id.btn_progress_record:
                    PageUtil.jumpToProgressRecord(mContext);
                    break;
            }
        }
    }
}
