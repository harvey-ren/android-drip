package com.xique.manage.construct.main.fragment;

import android.view.View;
import android.widget.TextView;

import com.rqphp.publib.base.BaseLazyFragment;
import com.xique.manage.construct.R;
import com.xique.manage.construct.util.PageUtil;

/**
 * @author Harvey
 * @description 我的界面
 * @date 2018/8/6 16:23
 * @copyright 成都喜鹊家居用品有限公司
 */
public class MyFragment extends BaseLazyFragment {
    @Override
    public void onLazyLoad() {

    }

    private TextView mBtnChangePassword;

    @Override
    protected int setLayoutResId() {
        return R.layout.fragment_my;
    }

    @Override
    protected void onInit(View view) {
        mBtnChangePassword = view.findViewById(R.id.btn_change_password);
        mBtnChangePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PageUtil.jumpToChangePassword(getActivity());
            }
        });
    }
}
