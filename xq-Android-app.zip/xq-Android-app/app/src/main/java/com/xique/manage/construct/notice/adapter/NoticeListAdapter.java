package com.xique.manage.construct.notice.adapter;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.annotation.NonNull;
import android.support.v7.widget.DrawableUtils;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.alibaba.android.arouter.facade.annotation.Route;
import com.rqphp.publib.adapter.FooterStatusRecyclerViewAdapter;
import com.rqphp.publib.adapter.HeaderFooterRecyclerViewAdapter;
import com.rqphp.publib.base.BaseViewHolder;
import com.rqphp.publib.util.PageJumpUtil;
import com.rqphp.publib.util.ResourcesUtil;
import com.xique.manage.construct.R;
import com.xique.manage.construct.notice.activity.NoticeDetailActivity;
import com.xique.manage.construct.util.PageUtil;

/**
 * @author Harvey
 * @description 消息通知列表适配器
 * @date 2018/8/10 11:26
 * @copyright 成都喜鹊家居用品有限公司
 */
public class NoticeListAdapter extends RecyclerView.Adapter<BaseViewHolder> {

    private Context mContext;

    public NoticeListAdapter(Context context) {
        mContext = context;
    }


    @NonNull
    @Override
    public BaseViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.item_notice_list, viewGroup, false);
        return new NoticeListViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull BaseViewHolder baseViewHolder, int position) {
        baseViewHolder.renderView(position);
    }

    @Override
    public int getItemCount() {
        return 35;
    }


    class NoticeListViewHolder extends BaseViewHolder implements View.OnClickListener {

        TextView mTvNoticeType;
        TextView mTvNoticeTitle;
        TextView mTvTime;


        public NoticeListViewHolder(View convertView) {
            super(convertView);
            mTvNoticeType = convertView.findViewById(R.id.tv_notice_type);
            mTvNoticeTitle = convertView.findViewById(R.id.tv_notice_title);
            mTvTime = convertView.findViewById(R.id.tv_time);
            convertView.setOnClickListener(this);
        }

        @Override
        public void renderView(int position) {
            super.renderView(position);

            if (position % 2 == 0) {
                mTvNoticeType.setBackground(ResourcesUtil.getDrawable(mContext, R.drawable.bg_circle_5b64cc));
                mTvNoticeTitle.setText("派工消息");
                mTvNoticeType.setText("派");
            } else if (position % 3 == 0) {
                mTvNoticeType.setBackground(ResourcesUtil.getDrawable(mContext, R.drawable.bg_circle_cca05b));
                mTvNoticeTitle.setText("物料消息");
                mTvNoticeType.setText("物");
            } else if (position % 5 == 0) {
                mTvNoticeType.setBackground(ResourcesUtil.getDrawable(mContext, R.drawable.bg_circle_bc5bcc));
                mTvNoticeTitle.setText("进度消息");
                mTvNoticeType.setText("进");
            } else {
                mTvNoticeType.setBackground(ResourcesUtil.getDrawable(mContext, R.drawable.bg_circle_5b87cc));
                mTvNoticeTitle.setText("系统消息");
                mTvNoticeType.setText("系");
            }
        }

        @Override
        public void onClick(View view) {
            PageUtil.jumpToNoticeDetail(mContext);
        }
    }
}
