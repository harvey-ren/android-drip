package com.xique.manage.construct.util;


import android.content.Context;
import android.support.v7.widget.RecyclerView;

import com.rqphp.publib.util.DateUtil;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.footer.ClassicsFooter;
import com.scwang.smartrefresh.layout.header.ClassicsHeader;
import com.xique.manage.construct.R;

import java.text.SimpleDateFormat;

/**
 * RecyclerView 工具类
 * <p>
 * Created by Harvey on 2017/8/21.
 */
public class RecyclerViewUtil {

    /**
     * 获取RecyclerView
     *
     * @param layoutManager
     * @param animator
     * @param hasFixedSize
     * @return
     */
    public static RecyclerView getRecyclerView(Context context, SmartRefreshLayout smartRefreshLayout,
                                               RecyclerView mRecyclerView, RecyclerView.LayoutManager layoutManager,
                                               RecyclerView.ItemAnimator animator, boolean hasFixedSize) {
        mRecyclerView.setLayoutManager(layoutManager);
        mRecyclerView.setItemAnimator(animator);
        mRecyclerView.setHasFixedSize(hasFixedSize);
        ClassicsHeader classicsHeader = new ClassicsHeader(context);
        classicsHeader.setArrowResource(R.mipmap.ic_arrow_down_refresh);
        classicsHeader.setTimeFormat(new SimpleDateFormat("最近更新：" + DateUtil.FORMAT_LONG));
        smartRefreshLayout.setRefreshHeader(classicsHeader);
        return mRecyclerView;
    }

}
