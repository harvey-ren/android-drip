package com.xique.manage.construct.main.activity;

import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.alibaba.android.arouter.facade.annotation.Route;
import com.githang.statusbar.StatusBarCompat;
import com.rqphp.publib.activity.BaseActivity;
import com.rqphp.publib.config.FrameworkConfig;
import com.rqphp.publib.util.ResourcesUtil;
import com.rqphp.publib.view.NetWorkImageView;
import com.xique.manage.construct.R;
import com.xique.manage.construct.main.adapter.MainPagerAdapter;
import com.xique.manage.construct.main.fragment.AllProjectFragment;
import com.xique.manage.construct.main.fragment.CurProjectFragment;
import com.xique.manage.construct.main.fragment.MyFragment;
import com.xique.manage.construct.util.PageUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * 主界面
 *
 * @author Harvey
 * @date 2018/7/25
 */
@Route(path = PageUtil.PATH_PAGE_MAIN)
public class MainActivity extends BaseActivity implements View.OnClickListener {

    private LinearLayout mLayoutLeft;
    private LinearLayout mLayoutRight;
    private TextView mTvTitle;
    private DrawerLayout mDrawerLayout;

    private ViewPager mViewPager;
    private TabLayout mTabLayout;

    private String[] mTabTitles = new String[]{"全部", "项目", "我的"};
    private int[] mTabIcons = new int[]{
            R.drawable.all_project_selector,
            R.drawable.cur_project_selector,
            R.drawable.my_selector
    };

    private NetWorkImageView mImageView;
    private LinearLayout mLayoutProjectList;
    private LinearLayout mLayoutFeedback;
    private LinearLayout mLayoutSetting;

    public void initViews() {
        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        mViewPager = (ViewPager) findViewById(R.id.viewPager);
        mTabLayout = (TabLayout) findViewById(R.id.tabLayout);
        mImageView = findViewById(R.id.imageView);
        mLayoutProjectList = (LinearLayout) findViewById(R.id.layout_project_list);
        mLayoutFeedback = (LinearLayout) findViewById(R.id.layout_feedback);
        mLayoutSetting = (LinearLayout) findViewById(R.id.layout_setting);
    }


    @Override
    protected int setContentViewId() {
        return R.layout.activity_main;
    }


    @Override
    protected void setStatusBarColor() {
        StatusBarCompat.setTranslucent(getWindow(), true);
    }

    @Override
    protected void onInit() {
        initViews();

        mLayoutProjectList.setOnClickListener(this);
        mLayoutFeedback.setOnClickListener(this);
        mLayoutSetting.setOnClickListener(this);

        initOther();
    }

    private void initOther() {

        mLayoutLeft = findViewById(R.id.layout_left);
        mLayoutRight = findViewById(R.id.layout_right);
        mTvTitle = findViewById(R.id.tv_title);
        mTvTitle.setText(ResourcesUtil.getString(this, R.string.app_name));
        mTvTitle.setTextColor(ResourcesUtil.getColor(this,
                FrameworkConfig.getIFrameworkConfig().getFrameworkResConfig().getTitleTextColor()));
        createActionBarIcon(mLayoutLeft, R.mipmap.ic_menu);
        createActionBarIcon(mLayoutRight, R.mipmap.ic_notice);
        mLayoutLeft.setOnClickListener(this);
        mLayoutRight.setOnClickListener(this);
        mDrawerLayout = findViewById(R.id.drawer_layout);

        List<Fragment> fragments = new ArrayList<>();
        fragments.add(new AllProjectFragment());
        fragments.add(new CurProjectFragment());
        fragments.add(new MyFragment());
        MainPagerAdapter adapter = new MainPagerAdapter(getSupportFragmentManager(), fragments, mTabTitles);
        mViewPager.setAdapter(adapter);
        mTabLayout.setupWithViewPager(mViewPager);
        setupTabIcons();
        mViewPager.setCurrentItem(1);
    }

    private void setupTabIcons() {
        mTabLayout.getTabAt(0).setCustomView(getTabView(0));
        mTabLayout.getTabAt(1).setCustomView(getTabView(1));
        mTabLayout.getTabAt(2).setCustomView(getTabView(2));
    }


    public View getTabView(int position) {
        View view = LayoutInflater.from(this).inflate(R.layout.tab_item, null);

        ImageView img_tab = view.findViewById(R.id.img_tab_item);
        img_tab.setImageResource(mTabIcons[position]);

        TextView tv_tab = view.findViewById(R.id.tv_tab_item);
        tv_tab.setText(mTabTitles[position]);

        return view;
    }


    /**
     * 设置标题栏左右图标
     */
    public View createActionBarIcon(ViewGroup root, int resImageId) {
        View view = getLayoutInflater().inflate(R.layout.view_title_img, root);
        ImageView imgLeft = view.findViewById(R.id.img_title);
        imgLeft.setImageResource(resImageId);
        return view;
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {

            case R.id.layout_left:
                mDrawerLayout.openDrawer(Gravity.LEFT, true);
                break;

            case R.id.layout_right:
                PageUtil.jumpToNoticeList(this);
                break;

            case R.id.layout_setting:
                PageUtil.jumpToAccountSetting(this);
                break;

            case R.id.layout_feedback:
                PageUtil.jumpToFeedback(this);
                break;

            case R.id.layout_project_list:
                PageUtil.jumpToProjectList(this);
                break;

        }
    }
}
