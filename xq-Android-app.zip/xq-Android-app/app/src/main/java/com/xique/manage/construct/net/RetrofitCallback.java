package com.xique.manage.construct.net;

/**
 * @author Harvey
 * @description 网络请求后的回调接口
 * @date 2018/7/27 17:40
 * @copyright 成都喜鹊家居用品有限公司
 */
public interface RetrofitCallback<T> {
    void onSuccess(T ret);

    void onError(int errCode, String errMsg);

    void onFailure();
}
