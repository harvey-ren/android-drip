package com.xique.manage.construct.util;

import android.content.Context;
import android.support.v4.app.ActivityOptionsCompat;

import com.alibaba.android.arouter.launcher.ARouter;
import com.xique.manage.construct.R;

/**
 * 路径工具类型
 *
 * @author Harvey
 * @date 2018/7/26 10:47
 */
public class PageUtil {

    public static final String BASE_PATH = "/xique/";

    /**
     * 主界面
     */
    public static final String PATH_PAGE_MAIN = BASE_PATH + "main";


    /**
     * 登录
     */
    public static final String PATH_PAGE_LOGIN = BASE_PATH + "login";

    /**
     * 派工
     */
    public static final String PATH_PAGE_ASSIGN = BASE_PATH + "assign";

    /**
     * 个人中心
     */
    public static final String PATH_PAGE_PERSONAL_CENTER = BASE_PATH + "personal_center";

    /**
     * 仓库
     */
    public static final String PATH_PAGE_REPOSITORY = BASE_PATH + "repository";


    /**
     * 忘记密码
     */
    public static final String PATH_PAGE_FORGET_PASSWORD = BASE_PATH + "forget_password";

    /**
     * 进度打卡
     */
    public static final String PATH_PAGE_PROGRESS_RECORD = BASE_PATH + "progress_record";


    /**
     * 意见反馈界面
     */
    public static final String PATH_PAGE_FEEDBACK = BASE_PATH + "feedback";

    /**
     * 消息通知列表界面
     */
    public static final String PATH_PAGE_NOTICE_LIST = BASE_PATH + "notice_list";

    /**
     * 消息详情界面
     */
    public static final String PATH_PAGE_NOTICE_DETAIL = BASE_PATH + "notice_detail";

    /**
     * 账号设置
     */
    public static final String PATH_PAGE_ACCOUNT_SETTING = BASE_PATH + "account_setting";

    /**
     * 补料界面
     */
    public static final String PATH_PAGE_ADD_MATERIAL = BASE_PATH + "add_material";

    /**
     * 验料
     */
    public static final String PATH_PAGE_CHECKOUT_MATERIAL = BASE_PATH + "checkout_material";

    /**
     * 延期原因
     */
    public static final String PATH_PAGE_DELAY_REASON = BASE_PATH + "delay_reason";

    /**
     * 当前项目
     */
    public static final String PATH_PAGE_CUR_PROJECT = BASE_PATH + "cur_project";

    /**
     * 项目列表
     */
    public static final String PATH_PAGE_PROJECT_LIST = BASE_PATH + "project_list";

    /**
     * 异常提交
     */
    public static final String PATH_PAGE_EXCEPTION_SUBMIT = BASE_PATH + "exception_submit";

    /**
     * 回料
     */
    public static final String PATH_PAGE_RECYCLE_MATERIAL = BASE_PATH + "recycle_material";

    /**
     * 点工
     */
    public static final String PATH_PAGE_TEMP_WORKER = BASE_PATH + "temp_worker";

    /**
     * 工时打卡
     */
    public static final String PATH_PAGE_WORK_HOURS_RECORD = BASE_PATH + "work_hours_record";

    /**
     * 修改密码
     */
    public static final String PATH_PAGE_CHANGE_PASSWORD = BASE_PATH + "change_password";

    /**
     * 转场动画
     *
     * @param context
     * @return
     */
    private static ActivityOptionsCompat getPageJumpAimation(Context context) {
        return ActivityOptionsCompat.makeCustomAnimation(context, R.anim.slide_in_right, R.anim.slide_out_left);
    }

    private static void setARouterPath(Context context, String path) {
        ActivityOptionsCompat compat = getPageJumpAimation(context);
        ARouter.getInstance().build(path).withOptionsCompat(compat).navigation();
    }

    /**
     * 跳转到主界面
     *
     * @param context
     */
    public static void jumpToMainPage(Context context) {
        setARouterPath(context, PATH_PAGE_MAIN);
    }

    /**
     * 跳转到登录界面
     *
     * @param context
     */
    public static void jumpToLoginPage(Context context) {
        setARouterPath(context, PATH_PAGE_LOGIN);
    }

    /**
     * 跳转到派工界面
     *
     * @param context
     */
    public static void jumpToAssignPage(Context context) {
        setARouterPath(context, PATH_PAGE_ASSIGN);
    }


    /**
     * 跳转到个人中心
     *
     * @param context
     */
    public static void jumpToPersonalCenterPage(Context context) {
        setARouterPath(context, PATH_PAGE_PERSONAL_CENTER);
    }

    /**
     * 跳转知识库
     *
     * @param context
     */
    public static void jumpToRepositoryPage(Context context) {
        setARouterPath(context, PATH_PAGE_REPOSITORY);
    }


    /**
     * 跳转忘记密码界面
     *
     * @param context
     */
    public static void jumpForgetPasswordPage(Context context) {
        setARouterPath(context, PATH_PAGE_FORGET_PASSWORD);
    }


    /**
     * 进度打卡
     *
     * @param context
     */
    public static void jumpToProgressRecord(Context context) {
        setARouterPath(context, PATH_PAGE_PROGRESS_RECORD);
    }

    /**
     * 跳转到意见反馈
     *
     * @param context
     */
    public static void jumpToFeedback(Context context) {
        setARouterPath(context, PATH_PAGE_FEEDBACK);
    }

    /**
     * 消息通知列表
     *
     * @param context
     */
    public static void jumpToNoticeList(Context context) {
        setARouterPath(context, PATH_PAGE_NOTICE_LIST);
    }

    /**
     * 消息详情
     *
     * @param context
     */
    public static void jumpToNoticeDetail(Context context) {
        setARouterPath(context, PATH_PAGE_NOTICE_DETAIL);
    }

    /**
     * 账号设置界面
     *
     * @param context
     */
    public static void jumpToAccountSetting(Context context) {
        setARouterPath(context, PATH_PAGE_ACCOUNT_SETTING);
    }

    /**
     * 补料界面
     *
     * @param context
     */
    public static void jumpToAddMaterial(Context context) {
        setARouterPath(context, PATH_PAGE_ADD_MATERIAL);
    }

    /**
     * 验料
     *
     * @param context
     */
    public static void jumpToCheckoutMaterial(Context context) {
        setARouterPath(context, PATH_PAGE_CHECKOUT_MATERIAL);
    }

    /**
     * 延期原因
     *
     * @param context
     */
    public static void jumpToDelayReason(Context context) {
        setARouterPath(context, PATH_PAGE_DELAY_REASON);
    }


    /**
     * 当前项目
     *
     * @param context
     */
    public static void jumpToCurProject(Context context) {
        setARouterPath(context, PATH_PAGE_CUR_PROJECT);
    }


    /**
     * 项目列表
     *
     * @param context
     */
    public static void jumpToProjectList(Context context) {
        setARouterPath(context, PATH_PAGE_PROJECT_LIST);
    }

    /**
     * 异常提交
     *
     * @param context
     */
    public static void jumpToExceptionSubmit(Context context) {
        setARouterPath(context, PATH_PAGE_EXCEPTION_SUBMIT);
    }

    /**
     * 回料界面
     *
     * @param context
     */
    public static void jumpToRecycleMaterial(Context context) {
        setARouterPath(context, PATH_PAGE_RECYCLE_MATERIAL);
    }


    /**
     * 点工界面
     *
     * @param context
     */
    public static void jumpToTempWorker(Context context) {
        setARouterPath(context, PATH_PAGE_TEMP_WORKER);
    }

    /**
     * 工时打卡
     *
     * @param context
     */
    public static void jumpToWorkHoursRecord(Context context) {
        setARouterPath(context, PATH_PAGE_WORK_HOURS_RECORD);
    }

    /**
     * 修改密码
     *
     * @param context
     */
    public static void jumpToChangePassword(Context context) {
        setARouterPath(context, PATH_PAGE_CHANGE_PASSWORD);
    }
}
