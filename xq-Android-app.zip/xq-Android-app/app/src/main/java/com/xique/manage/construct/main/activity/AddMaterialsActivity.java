package com.xique.manage.construct.main.activity;


import com.alibaba.android.arouter.facade.annotation.Route;
import com.rqphp.publib.activity.BaseTitleActivity;
import com.rqphp.publib.util.ResourcesUtil;
import com.xique.manage.construct.R;
import com.xique.manage.construct.util.PageUtil;

/**
 * 补料
 */
@Route(path = PageUtil.PATH_PAGE_ADD_MATERIAL)
public class AddMaterialsActivity extends BaseTitleActivity {

    @Override
    protected void onInit() {
        setTitleText(ResourcesUtil.getString(this, R.string.replenish_materials));
    }

    @Override
    protected int setLayoutResId() {
        return R.layout.activity_replenish_materials;
    }

}
