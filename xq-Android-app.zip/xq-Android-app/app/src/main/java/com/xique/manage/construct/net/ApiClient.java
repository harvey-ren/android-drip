package com.xique.manage.construct.net;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.text.TextUtils;

import com.rqphp.publib.dailog.LoadingDialog;

import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * @author Harvey
 * @description
 * @date 2018/7/27 16:52
 * @copyright 成都喜鹊家居用品有限公司
 */
public class ApiClient {

    private static ApiClient mClient;

    public Retrofit mRetrofit;

    private Context mContext;

    private LoadingDialog mDialog;

    /**
     * 是否显示加载对话框
     */
    private boolean isShowTip = false;

    private Call mCall;

    public static ApiClient getInstance() {

        if (mClient == null) {
            synchronized (ApiClient.class) {
                if (mClient == null) {
                    mClient = new ApiClient();
                }
            }
        }
        return mClient;
    }

    private ApiClient() {

        OkHttpClient okHttpClient = new OkHttpClient.Builder()
                .connectTimeout(10, TimeUnit.SECONDS)
                .readTimeout(10, TimeUnit.SECONDS)
                .writeTimeout(10, TimeUnit.SECONDS)
                .addInterceptor(new MoreUrlInterceptor())
                .build();

        mRetrofit = new Retrofit.Builder()
                .baseUrl(ApiConfig.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(okHttpClient)
                .build();
    }


    public <T> T getRequestService(Class<T> service) {
        return mRetrofit.create(service);
    }


    public <T> void request(Context context, Call<T> call, final RetrofitCallback callback) {
        this.request(context, "", call, callback);
    }

    public <T> void request(Context context, String tip, Call<T> call, final RetrofitCallback callback) {
        mContext = context;
        setDialogTip(tip);
        showDialog();
        mCall = call;

        mCall.enqueue(new Callback<T>() {
            @Override
            public void onResponse(Call<T> call, Response<T> response) {
                dismissDialog();
                if (response.isSuccessful()) {
                    callback.onSuccess(response.body());
                } else {
                    callback.onFailure();
                }
            }

            @Override
            public void onFailure(Call<T> call, Throwable t) {
                dismissDialog();
                callback.onFailure();
            }
        });
    }

    /**
     * 设置对话框的提示信息
     *
     * @param tip
     */
    public void setDialogTip(String tip) {
        if (!TextUtils.isEmpty(tip)) {
            isShowTip = true;
        } else {
            isShowTip = false;
        }
        if (isShowTip) {
            mDialog = new LoadingDialog(mContext);
            mDialog.setTipText(tip);
            mDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
                @Override
                public void onCancel(DialogInterface dialogInterface) {
                    dismissDialog();
                    if (mCall != null && !mCall.isCanceled()) {
                        mCall.cancel();
                    }
                }
            });
        }
    }


    private void showDialog() {
        if (mContext instanceof Activity) {
            Activity activity = (Activity) mContext;
            if (isShowTip && mDialog != null && !mDialog.isShowing() && !activity.isFinishing()) {
                mDialog.show();
            }
        }
    }


    private void dismissDialog() {
        if (isShowTip && mDialog != null && mDialog.isShowing()) {
            mDialog.dismiss();
        }
    }


}
