package com.xique.manage.construct.main.fragment;

import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.rqphp.publib.base.BaseLazyFragment;
import com.xique.manage.construct.main.adapter.CurProjectRecyclerViewAdapter;
import com.xique.manage.construct.util.RecyclerViewUtil;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.xique.manage.construct.R;

/**
 * @author Harvey
 * @description 当前项目
 * @date 2018/8/6 16:22
 * @copyright 成都喜鹊家居用品有限公司
 */
public class CurProjectFragment extends BaseLazyFragment {

    private SmartRefreshLayout mRefreshLayout;
    private RecyclerView mRecyclerView;


    @Override
    public void onLazyLoad() {

    }

    @Override
    protected int setLayoutResId() {
        return R.layout.layout_smartrefreshlayout_recyclerview;
    }

    @Override
    protected void onInit(View view) {
        mRefreshLayout = view.findViewById(R.id.refreshLayout);
        mRecyclerView = view.findViewById(R.id.recyclerView);
        RecyclerViewUtil.getRecyclerView(getActivity(), mRefreshLayout, mRecyclerView,
                new LinearLayoutManager(getActivity()), new DefaultItemAnimator(), true);
        CurProjectRecyclerViewAdapter curProjectAdapter = new CurProjectRecyclerViewAdapter(getActivity());
        mRecyclerView.setAdapter(curProjectAdapter);
    }
}
