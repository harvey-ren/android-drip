package com.xique.manage.construct.net;

import android.content.Context;
import android.support.annotation.NonNull;

import com.bumptech.glide.Glide;
import com.bumptech.glide.GlideBuilder;
import com.bumptech.glide.Registry;
import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.integration.okhttp3.OkHttpUrlLoader;
import com.bumptech.glide.load.engine.cache.ExternalPreferredCacheDiskCacheFactory;
import com.bumptech.glide.load.model.GlideUrl;
import com.bumptech.glide.module.AppGlideModule;

import java.io.InputStream;

/**
 * @author Harvey
 * @description Glide3需要在AndroidManifest.xml中配置, Glide4只需要@GlideModule注解就好
 * @date 2018/7/31 17:39
 * @copyright 成都喜鹊家居用品有限公司
 */
@GlideModule
public class IGlideModule extends AppGlideModule {

    /**
     * 缓存图片的大小是500M
     */
    public static final int DISK_CACHE_SIZE = 500 * 1024 * 1024;

    public static final String DISK_CACHE_NAME = "xique";

    @Override
    public void applyOptions(@NonNull Context context, @NonNull GlideBuilder builder) {
        super.applyOptions(context, builder);
        builder.setDiskCache(new ExternalPreferredCacheDiskCacheFactory(context, DISK_CACHE_NAME, DISK_CACHE_SIZE));
    }


    @Override
    public void registerComponents(@NonNull Context context, @NonNull Glide glide, @NonNull Registry registry) {
        super.registerComponents(context, glide, registry);
        registry.replace(GlideUrl.class, InputStream.class, new OkHttpUrlLoader.Factory());
    }
}
