package com.xique.manage.construct.main.activity;

import com.alibaba.android.arouter.facade.annotation.Route;
import com.rqphp.publib.activity.BaseTitleActivity;
import com.rqphp.publib.util.ResourcesUtil;
import com.xique.manage.construct.R;
import com.xique.manage.construct.util.PageUtil;

/**
 * @author Harvey
 * @description
 * @date 2018/8/10 18:43
 * @copyright 成都喜鹊家居用品有限公司
 */
@Route(path = PageUtil.PATH_PAGE_EXCEPTION_SUBMIT)
public class ExceptionSubmitActivity extends BaseTitleActivity {

    @Override
    protected int setLayoutResId() {
        return R.layout.layout_smartrefreshlayout_recyclerview;
    }

    @Override
    protected void onInit() {
        setTitleText(ResourcesUtil.getString(this,R.string.exception_submit));
    }
}
